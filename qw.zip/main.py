from flask import Flask
from flask import render_template
from flask import url_for
from flask import request
import json
import codecs
from flask import redirect
from flask import jsonify


app=Flask(__name__)
@app.route("/",methods=['GET'])
def index():
    mas=[[i,i+1,i+2,i+3] for i in range(1,53,4)]
    print(len(mas))
    return render_template('index.html',mas_number_card=mas)
if __name__=="__main__":
    app.run()