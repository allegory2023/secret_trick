from flask import Flask, render_template
from flask import request
from flask import redirect
import time 
import json 
from flask import jsonify
from flask import url_for
app = Flask(__name__)
global q
q=""
global tr
tr=False
@app.route('/focus/number/<num>',)
def index2(num):
    _dict={1: 'туз крести', 2: ' туз бубен', 3: ' туз червей', 4: ' туз пик', 5: '2 треф', 6: ' 2 бубен', 7: ' 2 червей', 8: ' 2 пик', 9: '3 крести', 10: ' 3 бубен', 11: 
     ' 3 червей', 12: ' 3 пик', 13: '4 треф', 14: ' 4 бубен', 15: ' 4 червей', 16: ' 4 пик', 17: '5 крести', 18: ' 5 бубен', 19: ' 5 червей', 20: ' 5 пик', 21: '6 крести', 22: '6 бубен', 23: ' 6 червей', 24: '6 пик', 25: '7 крести', 26: ' 7 бубен', 27: ' 7 червей', 28: ' 7 пик', 29: '8 крести', 30: ' 8 бубен', 31: ' 8 червей', 32: ' 8 пик', 33: '9 крести', 34: ' 9 бубен', 35: ' 9 червей', 36: ' 9 пик', 37: '10 крести', 38: ' 10 бубен', 39: ' 10 червей', 40: ' 10 пик', 41: 'Валет  крести', 42: ' Валет  бубен', 43: ' Валет  червей', 44: ' Валет  пик', 45: 'Дама  крести', 46: ' Дама  бубен', 47: ' Дама  червей', 48: ' Дама  пик', 49: 'Король  крести', 50: ' Король бубен', 51: 'Король  червей', 52: ' Король  пик'}
    global q
    global tr
    tr=True
    q=_dict[int(num)]
    print(q)
    return jsonify({"num":num})
@app.route('/result',methods=["GET"])
def indx():
    global q
    global tr
    if tr==True:
        tr=False
        return json.dumps({"code":q,"st":True})

    return json.dumps({"code":q,"st":tr})
@app.route('/',methods=['GET'])
def index1():
    return render_template("focus.html")
if __name__=="__main__":
    app.run()

    






