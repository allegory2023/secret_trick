function sayHi() {
   
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'http://yaroslav17031703.pythonanywhere.com/result',true);
    xhr.setRequestHeader('Access-Control-Allow-Origin', "http://yaroslav17031703.pythonanywhere.com/");
    xhr.setRequestHeader('Access-Control-Allow-Headers', 'origin, content-type, accept');
    xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');
    xhr.setRequestHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    xhr.send();
    if (xhr.status != 200) {
    let div = document.createElement('div');
div.className = "alert";
div.innerHTML = "<strong>Всем привет!</strong> Вы прочитали важное сообщение.";
 
  alert( xhr.status + ': ' + xhr.statusText+"gg" ); 
  
} else {
    let div = document.createElement('div');
div.className = "alert";
div.innerHTML = "<strong>Всем привет!</strong> Вы прочитали важное сообщение.";
  
  alert( xhr.responseText ); 
}
}


setInterval(sayHi, 5000);