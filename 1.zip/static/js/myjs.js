setInterval(
  function () {
    $.get("/result", function(data) {
      let k= $.parseJSON(data);
      if (Boolean(k['st'])){
        window.location.replace("https://yandex.kz/images/search?text="+k['code']);
      }
      
    })
  }, 
6000);